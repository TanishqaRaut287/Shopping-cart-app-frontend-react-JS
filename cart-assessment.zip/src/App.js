import React from 'react';
import ShoppingPage from './screens/Authenticated/ShoppingPage/ShoppingPage';

function App() {
  return (
    <div className="App">
      <ShoppingPage />
    </div>
  );
}

export default App;

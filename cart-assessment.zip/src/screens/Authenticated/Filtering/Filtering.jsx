import {useState} from 'react';
import { Fab, Typography, Box, Divider } from '@mui/material';

const Filtering = () => {

    const [size, setSize] = useState('');
     
    const handleXS = () => {
        setSize('XS');
    }
    const handleS = () => {
        setSize('S');
    }
    const handleM = () => {
        setSize('M');
    }
    const handleML = () => {
        setSize('ML');
    }
    const handleL = () => {
        setSize('L');
    }
    const handleXL = () => {
        setSize('XL');
    }
    const handleXXL = () => {
        setSize('XXL');
    }

    return (
        <div>
            <Box sx={{
                padding: "1rem"
            }}>

                <Typography sx={{ margin: "10px" }}>Sizes</Typography>

                <Divider />

                <Box sx={{marginTop: "1rem"}}>
                    <Fab onClick={handleXS} size="small" sx={{ margin: "4px" }}>
                        XS
                    </Fab>
                    <Fab size="small" onClick={handleS} aria-label="add" sx={{ margin: "4px" }}>
                        S
                    </Fab>
                    <Fab size="small" onClick={handleM} aria-label="add" sx={{ margin: "4px" }}>
                        M
                    </Fab>
                    <Fab size="small" onClick={handleML} aria-label="add" sx={{ margin: "4px" }}>
                        ML
                    </Fab>
                    <Fab size="small" onClick={handleL} aria-label="add" sx={{ margin: "4px" }}>
                        L
                    </Fab>
                    <Fab size="small" onCLick={handleXL} aria-label="add" sx={{ margin: "4px" }}>
                        XL
                    </Fab>
                    <Fab size="small" onClick={handleXXL} aria-label="add" sx={{ margin: "4px" }}>
                        XXL
                    </Fab>
                </Box>

            </Box>

        </div>
    )
}

export default Filtering
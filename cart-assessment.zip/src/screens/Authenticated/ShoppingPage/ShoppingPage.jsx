import React, { useState, useEffect } from 'react'
import OutlinedCard from '../../../components/ProductCard/ProductCard'
import { Box, Grid, Typography, Divider } from '@mui/material';
import axios from 'axios';
import Filtering from '../Filtering/Filtering';
import PrimaryButton from '../../../components/Button/Button';

import { productsData } from '../../../utils/ProductsData';
const ShoppingPage = () => {

    const [data, setData] = useState([]);
    const [isFree, setIsFree] = useState("false");


    // console.log(productsData);

    // const Filtering = ({ size }) => {

    //     const [foundProducts, setFoundProducts] = useState(productsData);

    //     if (size !== '') {
    //         const results = productsData.filter((product) => {
    //             return product.availableSizes.toLowerCase()
    //         });
    //         setFoundProducts(results);
    //     }
    //     else {
    //         setFoundProducts(productsData);
    //     }
    // }

    //     return(
    //         <div>
    //         {foundProducts && foundProducts.length > 0 ? (
    //             foundProducts.map((product) => (
    //                 <Box>
    //             <Grid container spacing={2}>
    //                 <Grid item xs={2}>
    //                     <Filtering />
    //                 </Grid>
    //                 <Grid item xs={10}>
    //                     <Box 
    //                     sx = {{
    //                         padding: "5px",
    //                         margin: "10px"
    //                     }}
    //                     >
    //                         <Grid container spacing={1}>
    //                             <Grid item xs={2}>
    //                             <Typography sx={{padding: "10px"}}> {product.length} products available</Typography>
    //                             </Grid>
    //                             <Grid item xs={2} sx={{marginLeft: "820px"}}>
    //                             <PrimaryButton sx={{fontSize: 14, marginLeft: "50px"}}> Add Product</PrimaryButton>
    //                             </Grid>
    //                         </Grid>


    //                         <Divider sx={{marginBottom: "1rem"}}/>

    //                         <Grid container spacing={2}>
    //                             <Grid item xs={3}>
    //                                 <OutlinedCard
    //                                     title={products.title}
    //                                     price={products.price}
    //                                 />
    //                             </Grid>
    //                             <Grid item xs={3}>
    //                                 <OutlinedCard
    //                                     title={"Title"}
    //                                     price={"Price"} />
    //                             </Grid>
    //                             <Grid item xs={3}>
    //                                 <OutlinedCard
    //                                     title={"Title"}
    //                                     price={"Price"} />
    //                             </Grid>
    //                             <Grid item xs={3}>
    //                                 <OutlinedCard
    //                                     title={"Title"}
    //                                     price={"Price"} />
    //                             </Grid>

    //                         </Grid>

    //                     </Box >
    //                 </Grid>

    //             </Grid>
    //         </Box>
    //             ))
    //         ) : (<h1>No Products Available</h1>)
    //     } 
    //         </div>
    //     ); 
    // }


    return (
        <div>
            <Box>
                <Grid container spacing={2}>
                    <Grid item xs={2}>
                        <Filtering />
                    </Grid>
                    <Grid item xs={10}>
                        <Box
                            sx={{
                                padding: "5px",
                                margin: "10px"
                            }}
                        >
                            {/* {productsData.map((product) => (
                                return (<div key={product.id}> */}

                                <Grid container spacing={1}>
                                    <Grid item xs={2}>
                                        <Typography sx={{ padding: "10px" }}> {productsData.length} products available</Typography>
                                    </Grid>
                                    <Grid item xs={2} sx={{ marginLeft: "820px" }}>
                                        <PrimaryButton sx={{ fontSize: 14, marginLeft: "50px" }}> Add Product</PrimaryButton>
                                    </Grid>
                                </Grid>


                                <Divider sx={{ marginBottom: "1rem" }} />

                                <Grid container spacing={2}>
                                    <Grid item xs={3}>
                                        <OutlinedCard
                                            title={"products.title"}
                                            price={"products.price"}
                                        />
                                    </Grid>
                                    <Grid item xs={3}>
                                        <OutlinedCard
                                            title={"Title"}
                                            price={"Price"} />
                                    </Grid>
                                    <Grid item xs={3}>
                                        <OutlinedCard
                                            title={"Title"}
                                            price={"Price"} />
                                    </Grid>
                                    <Grid item xs={3}>
                                        <OutlinedCard
                                            title={"Title"}
                                            price={"Price"} />
                                    </Grid>

                                </Grid>

                            {/* </div> */}
                                {/* ))) */}



                        </Box >
                    </Grid>

                </Grid>
            </Box>

        </div >
    )
}

export default ShoppingPage
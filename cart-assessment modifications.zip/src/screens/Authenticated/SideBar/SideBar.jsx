import React from 'react'
import {Box, Grid} from '@mui/material'

import CartTotal from '../CartTotal/CartTotal'
import Filtering from '../Filtering/Filtering'


const SideBar = ({handleFilter, shoppingCart}) => {
  return (
    <div>
        <Box>
            <Grid container>
                <Grid item>
                    <Filtering handleFilter={handleFilter}  />
                </Grid>
                <Grid item>
                    <CartTotal shoppingCart={shoppingCart}/>
                </Grid>
            </Grid>
        </Box>
    </div>
  )
}

export default SideBar
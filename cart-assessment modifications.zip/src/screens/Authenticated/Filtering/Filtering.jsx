import {useState} from 'react';
import { Fab, Typography, Box, Divider } from '@mui/material';

const Filtering = ({handleFilter}) => {

    return (
        <div>
            <Box sx={{
                padding: "1rem"
            }}>

                <Typography sx={{ margin: "10px" }}>Sizes</Typography>

                <Divider />

                <Box sx={{marginTop: "1rem"}}>
                    <Fab onClick={()=>{handleFilter('XS')}} size="small" sx={{ margin: "4px" }}>
                        XS
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('S')}} aria-label="add" sx={{ margin: "4px" }}>
                        S
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('M')}} aria-label="add" sx={{ margin: "4px" }}>
                        M
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('ML')}} aria-label="add" sx={{ margin: "4px" }}>
                        ML
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('L')}} aria-label="add" sx={{ margin: "4px" }}>
                        L
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('XL')}} aria-label="add" sx={{ margin: "4px" }}>
                        XL
                    </Fab>
                    <Fab size="small" onClick={()=>{handleFilter('XXL')}} aria-label="add" sx={{ margin: "4px" }}>
                        XXL
                    </Fab>
                </Box>

            </Box>

        </div>
    )
}

export default Filtering
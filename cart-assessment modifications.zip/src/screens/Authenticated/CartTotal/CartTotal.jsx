import { Button, Divider, Typography } from '@mui/material';
import React, { useState } from 'react'
import { Box, Grid } from '@mui/material'

const CartTotal = ({ shoppingCart }) => {


    return (
        <div>
            <Box sx={{ padding: "1rem" }}>
                <Typography
                    sx={{ margin: "10px" }}
                >
                    Cart : ({shoppingCart.length})
                </Typography>
                <Divider />

                {shoppingCart.map((mycart) => {
                    return (
                        <Grid container key={mycart.id}>
                            <Grid item xs={12}>
                                <Typography>{mycart.title}</Typography>
                                <Typography>Quantity: {mycart.quantity}</Typography>
                                <br />
                                <Typography>{ '$' + mycart.price}</Typography>
                                <Button onClick={()=>mycart.quantity + 1}>+</Button>
                                <Button onClick = {()=>mycart.quantity - 1} >-</Button>
                            </Grid>
                           
                            <Grid item xs={12}>
                                <Typography>Total {'$' + (mycart.quantity * mycart.price)}</Typography>
                                <hr />
                            </Grid>
                            
                        </Grid>
                        
                    )

                })}
                



            </Box>

        </div>
    )
}

export default CartTotal;